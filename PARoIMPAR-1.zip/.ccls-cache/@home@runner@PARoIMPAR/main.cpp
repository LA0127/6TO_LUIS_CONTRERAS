#include <iostream>

using namespace std;
int main() {
  int a,b,c;
  cout << "Ingresa un numero: \n";
  cin>>a;
  
}